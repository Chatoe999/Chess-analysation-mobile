package com.chessanalysis.razbor;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.SafeBrowsingResponse;
import android.webkit.ServiceWorkerController;
import android.webkit.ServiceWorkerClient;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;


/**
 * Тонкая Android-оболочка для существующей веб-версии Chess-analysation-mobile.
 *
 * Важно: интерфейс и шахматная логика остаются в исходном index.html.
 * WebView открывает официальный GitHub Pages адрес, поэтому обновления сайта
 * становятся доступны приложению без пересборки APK.
 */
public class MainActivity extends Activity {
    private static final String APP_URL =
            "https://chatoe999.github.io/Chess-analysation-mobile/";
    private static final String APP_HOST = "chatoe999.github.io";

    private WebView webView;
    private FrameLayout root;

    @SuppressLint({"SetJavaScriptEnabled", "AllowUniversalAccessFromFileURLs"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Системные панели под цвет исходного сайта.
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(7, 6, 20));
        window.setNavigationBarColor(Color.rgb(7, 6, 20));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.setNavigationBarContrastEnforced(false);
        }

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(7, 6, 20));
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));
        setContentView(root);

        configureWebView();

        // Восстанавливаем WebView state при пересоздании Activity.
        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(APP_URL);
        }

    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView() {
        WebSettings settings = webView.getSettings();

        // Приложение написано на HTML/CSS/JavaScript и использует Worker/Stockfish.
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);       // localStorage для ника и настроек.
        settings.setDatabaseEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setBlockNetworkImage(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        // Сохраняем cookies, если сайт/источники партий их используют.
        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            webView.setSafeBrowsingEnabled(true);
        }
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);

        // Service Worker сайта продолжает работать: он кэширует оболочку PWA.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            ServiceWorkerController.getInstance().setServiceWorkerClient(
                    new ServiceWorkerClient() {
                        @Override
                        public android.webkit.WebResourceResponse shouldInterceptRequest(
                                WebResourceRequest request) {
                            return null; // Оставляем штатную обработку WebView.
                        }
                    }
            );
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme();
                String host = uri.getHost() == null ? "" : uri.getHost();

                // Основной сайт и его же страницы открываются внутри APK.
                if ("https".equalsIgnoreCase(scheme)
                        && (APP_HOST.equalsIgnoreCase(host)
                        || host.endsWith(".github.io"))) {
                    return false;
                }

                // Внешние ссылки (например, Chess.com) открываются в браузере.
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    openExternal(uri);
                    return true;
                }

                // Неизвестные схемы не передаём WebView.
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request,
                                        WebResourceError error) {
                super.onReceivedError(view, request, error);
                // Не показываем ошибку для каждого изображения/скрипта:
                // реагируем только на сбой главного документа.
                if (request.isForMainFrame()) {
                    Toast.makeText(MainActivity.this,
                            "Не удалось загрузить приложение. Проверь интернет.",
                            Toast.LENGTH_LONG).show();
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient());

        // Скачиваемые файлы передаются системному браузеру/загрузчику.
        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent,
                                        String contentDisposition, String mimeType,
                                        long contentLength) {
                openExternal(Uri.parse(url));
            }
        });
    }

    private void openExternal(@NonNull Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException ignored) {
            Toast.makeText(this, "Не найдено приложение для открытия ссылки.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.removeAllViews();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
