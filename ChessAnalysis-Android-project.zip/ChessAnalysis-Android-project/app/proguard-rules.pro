# WebView wrapper: no application code shrinking rules are needed yet.
