# Android APK для «Разбор партий»

Это Android WebView-оболочка для существующей веб-версии:
https://chatoe999.github.io/Chess-analysation-mobile/

HTML, CSS и JavaScript сайта не переписываются. APK открывает действующую
GitHub Pages версию, поэтому внешний вид и шахматная логика остаются такими же.
Обновления сайта становятся доступны в приложении без пересборки APK.

## Что поддерживает оболочка

- JavaScript и Web Workers, необходимые для Stockfish.
- DOM Storage / localStorage.
- Service Worker сайта и его кэш.
- HTTPS-запросы к GitHub Pages, Chess.com и CDN.
- Системную кнопку «Назад».
- Открытие внешних ссылок во внешнем браузере.
- Тёмные системные панели под цвета интерфейса.

## Сборка в основном репозитории с телефона

Чтобы не держать отдельный репозиторий `Chess-analysis-apk`:

1. Загрузи этот архив в корень `Chatoe999/Chess-analysation-mobile`
   с именем `ChessAnalysis-Android-project.zip`.
2. Создай в основном репозитории файл
   `.github/workflows/build-apk.yml` и вставь содержимое файла
   `build-apk.yml`, который приложен отдельно.
3. Открой GitHub → Actions → **Build Android APK** → **Run workflow**.
4. После зелёной галочки открой завершённый запуск и скачай artifact
   **chess-analysis-apk**.
5. Распакуй artifact ZIP и установи `app-debug.apk` на Android.

## Технические параметры

- Android applicationId: `com.chessanalysis.razbor.debug` для debug APK.
- Minimum Android: 6.0 (API 23).
- Target SDK: 34.
- JDK: 17.
- Gradle: 8.9.
- Android Gradle Plugin: 8.7.3.

## Важное ограничение

Для первой загрузки сайта и получения партий/движка нужен интернет.
Service Worker может сохранить часть сайта для повторного запуска офлайн,
но полный офлайн-анализ не гарантируется: Stockfish и некоторые библиотеки
загружаются с CDN. Функции остаются в исходной веб-версии.
